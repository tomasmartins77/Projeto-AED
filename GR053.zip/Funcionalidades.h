#ifndef Funcionalidades
#define Funcionalidades

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "modos.h"

/** \brief
 *
 */
int menu_perguntas(int **tab, lab_t lab, int A6_x, int A6_y);

/** \brief
 *
 */
int A1(int **tab, int x, int y);

/** \brief
 *
 */
int A234(int **tab, lab_t lab, int x, int y);

/** \brief
 *
 */
int A5(int **tab, lab_t lab);

int A6(int **tab, lab_t lab, int A6_x, int A6_y);

#endif
